// Data produk sederhana
const productsData = [
  { id: 1, name: "Sepatu Sneakers", price: 500000, image: "https://via.placeholder.com/200" },
  { id: 2, name: "Kaos Polos", price: 100000, image: "https://via.placeholder.com/200" },
  { id: 3, name: "Jam Tangan", price: 750000, image: "https://via.placeholder.com/200" },
];

let cart = JSON.parse(localStorage.getItem("cart")) || [];

// Update jumlah keranjang
function updateCartCount() {
  document.querySelectorAll("#cart-count").forEach(el => el.textContent = cart.length);
}

// Tambah ke keranjang
function addToCart(id) {
  const product = productsData.find(p => p.id === id);
  cart.push(product);
  localStorage.setItem("cart", JSON.stringify(cart));
  updateCartCount();
  alert(`${product.name} ditambahkan ke keranjang!`);
}

// Render produk di halaman index
const productsContainer = document.getElementById("products");
if (productsContainer) {
  productsData.forEach(product => {
    const div = document.createElement("div");
    div.className = "product";
    div.innerHTML = `
            <img src="${product.image}" alt="${product.name}">
            <h3>${product.name}</h3>
            <p>Rp ${product.price.toLocaleString()}</p>
            <button onclick="addToCart(${product.id})">Tambah ke Keranjang</button>
            <a href="product.html?id=${product.id}">Lihat Detail</a>
        `;
    productsContainer.appendChild(div);
  });
}

// Render detail produk
const detailContainer = document.getElementById("product-detail");
if (detailContainer) {
  const params = new URLSearchParams(window.location.search);
  const id = parseInt(params.get("id"));
  const product = productsData.find(p => p.id === id);
  if (product) {
    detailContainer.innerHTML = `
            <img src="${product.image}" alt="${product.name}">
            <h2>${product.name}</h2>
            <p>Harga: Rp ${product.price.toLocaleString()}</p>
            <button onclick="addToCart(${product.id})">Tambah ke Keranjang</button>
        `;
  } else {
    detailContainer.innerHTML = "<p>Produk tidak ditemukan</p>";
  }
}

// Render keranjang
const cartContainer = document.getElementById("cart-items");
if (cartContainer) {
  if (cart.length === 0) {
    cartContainer.innerHTML = "<p>Keranjang kosong</p>";
  } else {
    cart.forEach(item => {
      const div = document.createElement("div");
      div.className = "product";
      div.innerHTML = `
                <img src="${item.image}" alt="${item.name}">
                <h3>${item.name}</h3>
                <p>Rp ${item.price.toLocaleString()}</p>
            `;
      cartContainer.appendChild(div);
    });
  }
}

updateCartCount();